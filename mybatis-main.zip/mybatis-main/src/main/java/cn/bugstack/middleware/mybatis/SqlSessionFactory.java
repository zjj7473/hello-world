package cn.bugstack.middleware.mybatis;

/**
 * 公众号 | bugstack虫洞栈
 * 博 客 | https://bugstack.cn
 * Create by 小傅哥
 */
public interface SqlSessionFactory {

    SqlSession openSession();

}
