# mybatis-spring
仿照 mybatis-spring 实现 ORM 与 Spring 结合 | mybatis-spring
